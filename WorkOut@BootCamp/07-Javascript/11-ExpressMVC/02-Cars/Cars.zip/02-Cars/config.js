module.exports = {
    mysql: {
        host: 'localhost',
        user: 'root',
        password: '[-Mtngro27.Jsmsvr3-]',
        database: 'express_mvc_cars',
    },
    server: {
        port: process.env.PORT || 3306,
    },
};
