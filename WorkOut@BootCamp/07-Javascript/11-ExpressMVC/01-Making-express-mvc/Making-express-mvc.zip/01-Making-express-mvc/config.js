module.exports = {
    database: {
        host: 'localhost',
        username: 'your_username',
        password: 'your_password',
        database: 'your_database_name',
    },
};
