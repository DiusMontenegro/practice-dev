const express = require('express');
const app = express();

const server = app.listen(8000);
const io = require('socket.io')(server);

app.use(express.static(__dirname + '/public'));
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');

let participantsList = {};
let chatMessages = [];

app.get('/', (req,res) => {
    res.render('index');
});

io.on('connection', (socket) => {
    socket.emit('previous_chats', { messages: chatMessages });
    
    socket.on('got_new_user', (name) => {
        console.log(`${name.name} has joined the chat.`);
        participantsList[socket.id] = name.name;
        io.emit('active_participants', { participants: Object.values(participantsList) });
    });

    socket.on('send_message', ({ message, recipient }) => {
        if(recipient == "everyone"){
            chatMessages.push({ sender:participantsList[socket.id], message});
            io.emit('chat_message', { recipient: "everyone", sender:participantsList[socket.id], message });
        }else{
            const receiver = Object.keys(participantsList).find(socketID => participantsList[socketID] == recipient);
            io.to(receiver).emit('chat_message', { recipient: participantsList[receiver], sender:participantsList[socket.id], message });
            socket.emit('chat_message', { recipient: participantsList[receiver], sender:participantsList[socket.id], message });
        };
    });

    socket.on('disconnect', () => {
        const disconnectedUser = participantsList[socket.id];
        if (disconnectedUser) {
            console.log(`${disconnectedUser} has left the chat.`);
            io.emit('user_disconnected', { disconnected_user: disconnectedUser });
            delete participantsList[socket.id];
            io.emit('active_participants', { participants: Object.values(participantsList) });
        }
    });
});

