const string = require('./stringlib')();

console.log(string.concat('Village', '88'));
console.log(string.repeat('ha', 5));
console.log(string.toString(3));
console.log(string.charAt('nice', 2));
