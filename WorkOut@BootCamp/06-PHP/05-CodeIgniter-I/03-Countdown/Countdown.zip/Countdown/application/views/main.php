<?php ?>
    <h1>Countdown before the day ends</h1>
    <p>Countdown: <?= $date['countdown'] ?></p>
    <p>Date: <?= $date['current_date'] ?></p>
