<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>CI - Money Button Game</title>
    <link rel="stylesheet" href=<?= base_url('assets/styles.css');?>>
</head>
<body>
