    <form action=<?php echo base_url('users/create');?> method="POST">
        <input type="text" name="first_name" placeholder="Enter your first name">
        <input type="text" name="last_name" placeholder="Enter your last name">
        <input type="text" name="email" placeholder="Enter your email">
        <input type="submit" value="Submit">
    </form>
