<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Main</title>
    <style>
        h1 {
            color: blue;
        }
        .world {
            display: block;
            margin: 0px auto;
            width: 300px;
            height: 150px;
        }
        .ninja {
            width: 100px;
        }
        .users {
            color: brown;
        }
    </style>
</head>
<body>
