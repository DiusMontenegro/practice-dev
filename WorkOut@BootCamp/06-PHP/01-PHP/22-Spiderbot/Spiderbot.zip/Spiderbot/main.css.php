<?php
    header('Content-type: text/css');
?>

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'arial';
}

body {
    text-align: center;
    padding: 80px;
}

h1 {
    margin-top: 50px;
    margin-bottom: 40px;
}

p, a {
    text-decoration: none;
    font-size: 20px;
    margin-bottom: 20px;
    color: black;    
}



