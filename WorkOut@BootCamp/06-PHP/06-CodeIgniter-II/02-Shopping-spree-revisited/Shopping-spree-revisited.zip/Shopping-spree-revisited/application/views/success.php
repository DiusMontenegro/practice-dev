<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->view('partials/header');
?>
    <section class="success_page container">
        <h1 id="success">Payment Successful !</h1>
        <h5>The Developer is part of the team ketchup. </h5>
        <h5>Stripe payment will be available soon.</h5>
    </section>
<?php $this->load->view('partials/footer'); ?>
