<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Facebool</title>
    <link rel="stylesheet" href="main.css.php">
</head>
<body class="authorized-page" >
    <main class="logged">
        <img src="./img/success.gif" alt="success">
        <h2>"You made it! You've outsmarted the binary code, high-fived the algorithms, and arrived at the VIP section of the internet. Your virtual crown awaits!"</h2>
        <a href="./process.php">Log out</a>
    </main>
</body>
</html>
