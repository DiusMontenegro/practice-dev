<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->view('partials/header'); ?>
        <div id="pokemon" class="container"></div>
<?php $this->load->view('partials/footer'); ?>
