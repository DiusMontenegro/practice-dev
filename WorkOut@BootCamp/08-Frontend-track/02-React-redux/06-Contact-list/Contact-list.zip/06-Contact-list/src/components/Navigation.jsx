const Navigation = () => {
    return (
        <nav className='mb-3 h-10 text-center text-white font-bold text-3xl'>
            <p>Contact List</p>
        </nav>
    );
};

export default Navigation;
