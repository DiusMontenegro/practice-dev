import Lists from './components/Lists';

const App = () => {
    return <Lists />;
};

export default App;
